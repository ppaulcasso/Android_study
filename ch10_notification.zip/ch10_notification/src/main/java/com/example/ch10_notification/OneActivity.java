package com.example.ch10_notification;

import android.app.Activity;

public class OneActivity extends Activity {


}
